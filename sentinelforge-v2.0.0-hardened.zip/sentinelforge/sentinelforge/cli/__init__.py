"""SentinelForge CLI."""
