"""Module tests."""
