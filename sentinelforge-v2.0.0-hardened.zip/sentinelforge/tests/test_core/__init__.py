"""Core layer tests."""
