"""SentinelForge test suite."""
